package iss.java.mail;


import java.io.IOException;

import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

public class myclass2014302580175 implements IMailService {
	 /**
     * �����ʼ���props�ļ�
     */
    private final transient Properties props = System.getProperties();
    private final transient Properties props2 = System.getProperties();
    /**
     * �ʼ���������¼��֤
     */
    private transient MailAuthenticator authenticator;
    private transient MailAuthenticator authenticator2;

    /**
     * ����session
     */
    private transient Session session;
    private transient Session session2;
    //own
    String pop3HostName="pop3.163.com";
    String smtpHostName="smtp.163.com";
    String username="13343582606@163.com";
    String password="whu1314znz";
	 public void connect() throws MessagingException{
		 // ��ʼ��props
	        props.put("mail.smtp.auth", "true");
	        props.put("mail.smtp.host", smtpHostName);
	        // ��֤
	        authenticator = new MailAuthenticator(username, password);
	        authenticator2= new MailAuthenticator(username, password);
	        // ����session
	        session = Session.getInstance(props, authenticator);
	        // ��ʼ��props2
	        props2.put("mail.store.protocol", "pop3");
	        props2.put("mail.pop3.host", pop3HostName);
	        // ����session2
	        session2 = Session.getInstance(props2,authenticator2);
	 }
	 public void send(String recipient, String subject, Object content) throws MessagingException{
	        // ����mime�����ʼ�
	        final MimeMessage message = new MimeMessage(session);
	        // ���÷�����
	        message.setFrom(new InternetAddress(authenticator.getUsername()));
	        // �����ռ���
	        message.setRecipient(RecipientType.TO, new InternetAddress(recipient));
	        // ��������
	        message.setSubject(subject);
	        // �����ʼ�����
	        message.setContent(content.toString(), "text/html;charset=utf-8");
	        // ����
	        Transport.send(message);
	 }
	 
	 public boolean listen() throws MessagingException{
		 Store store = session2.getStore();
	        store.connect();

	        // ��������ڵ��ʼ���Folder������"ֻ��"��
	        Folder folder = store.getFolder("inbox");
	        folder.open(Folder.READ_ONLY);
	     // ����ռ�����ʼ��б�
	        System.out.println("���ʼ���Ŀ��" +   folder.getNewMessageCount());
	        System.out.println("δ���ʼ���Ŀ��" +   folder.getUnreadMessageCount());
	        if( folder.getUnreadMessageCount()==0){return false;}
	        else return true;
		 
	 }
	 
	 public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException{
		 Store store = session2.getStore();
	        store.connect();

	        // ��������ڵ��ʼ���Folder������"ֻ��"��
	        Folder folder = store.getFolder("inbox");
	        folder.open(Folder.READ_ONLY);
	     // ����ռ�����ʼ�
	        int num;
	        num=folder.getMessageCount();
	        Message message = folder.getMessage(num); 
	        

	             subject = message.getSubject();
	             sender = (message.getFrom()[0]).toString();
	        String str=message.getContent().toString();
	        folder.close(false);
	        store.close();
		 return str;
	 }
}
